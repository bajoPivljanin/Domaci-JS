let btn = document.querySelector('.animirani-text button')
let texth = document.querySelector('.animirani-text h1')
let text = texth.textContent
texth.innerHTML = ' '
let split = text.split('')
for(let i=0;i<split.length;i++)
{
    if(split[i] === " ")
        split[i] = "&nbsp"
    texth.innerHTML += `<span>${split[i]}</span>` 
}

k=0

let spans = texth.querySelectorAll('span')
btn.addEventListener("click",()=>{
        let duzina = spans.length
        let singlespan = spans[k]
        singlespan.className = 'fadeMove'
        k++
        if(k===duzina)
        {
            btn.innerText = 'Kraj'
            btn.setAttribute("disabled","true")
        }
})

let border = document.querySelector('.crta')
let btnplus = document.querySelector('.linija #plus')
let btnminus = document.querySelector('.linija #minus')
let animationWidth = 0
const plus = () => {
    animationWidth += 1.5
    if(animationWidth>= 100)
        animationWidth = 100
    border.style.width = animationWidth+'%'
}
const minus = () => {
    animationWidth -= 1.5
    if(animationWidth<=0)
        animationWidth = 0
    border.style.width = animationWidth+'%'
}
btnplus.addEventListener('click',plus)
btnminus.addEventListener('click',minus)

let btnLevo = document.querySelector('.slike #levo')
let btnDesno = document.querySelector('.slike #desno')
let prva = document.querySelector('.slike .images #prva')
let druga = document.querySelector('.slike .images #druga')
const levo = () => {
   let klasa = document.querySelector('.slike .images #prva')
   klasa.className = 'klasa'
}
const desno = () => {
    let klasa = document.querySelector('.slike .images #druga')
    klasa.className = 'klasa'
 }
btnLevo.addEventListener("click",levo)
btnDesno.addEventListener("click",desno)