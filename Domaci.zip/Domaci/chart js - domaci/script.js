const polarAreaChart = document.querySelector('#polarAreaChart')

new Chart (polarAreaChart,{
    type: 'polarArea',
    data: {
        labels: ['Srbija','Crna Gora','Hrvatska','BiH'],
        datasets:[
            {
                label: 'Populacija u drzavi',
                data: ['7186862','620739','3888529', '3475000'],
                backgroundColor:[
                    'rgba(78, 116, 224, 1)',
                    'rgba(247, 0, 5, 1)',
                    'rgba(255, 175, 176, 1)',
                    'rgba(0, 48, 255, 1)',
                ]
            }
        ]
    }
})