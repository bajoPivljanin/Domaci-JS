let logo = document.querySelector('.lnXdpd')

if(logo){
logo.src = chrome.runtime.getURL('images/cysecor_logo.png') 
logo.srcset = chrome.runtime.getURL('images/cysecor_logo.png') 
}


let google = document.querySelector('.logo img')
google.src = chrome.runtime.getURL('images/cysecor_logo.png') 
google.srcset = chrome.runtime.getURL('images/cysecor_logo.png') 