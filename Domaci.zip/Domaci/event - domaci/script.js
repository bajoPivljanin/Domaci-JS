let btns = document.querySelectorAll('.dugmad')

btns.forEach(function (btn) {
    btn.addEventListener("click", function() {
        let ispis = 'Kliknuo si dugme'
        document.write(ispis)
    })
})

let frm = document.querySelector('#forma')
frm.addEventListener('submit', e =>{
    e.preventDefault()
    let input = document.querySelector('#input').value
    if(input.length === 0)
        alert('Upisite text')
    else
        alert('Upisani text je: '+input)

})

let select = document.querySelector('#opcije')
select.addEventListener('change', e =>{
    alert('Izabrali ste opciju: ' + e.target.value)
})

window.addEventListener('resize', e =>{
    if(window.innerWidth > 1000)
        alert('Prozor je veci od 1000px')
})
let input = document.querySelector('#input')
input.addEventListener('keydown', e =>{
    if(e.key === " ")
        alert('kliknuo si space');
})
input.addEventListener('mousemove', e =>{
    console.log('pomera se kursor');
})
