let sveUkp = 0
function dodaj(element){
    let mainel = element.closest('.card')
    let cardmain = mainel.querySelector('.card-body')
    let cena = mainel.querySelector('#cena').innerText
    let pozDolar = cena.indexOf('$')
    cena = cena.substring(pozDolar+1)
    cena = parseInt(cena)
    sveUkp += cena 

    console.log(cardmain);
    document.querySelector('.ukupno').innerText=`Ukupan iznos je $${sveUkp}`

    element.innerText='Dodato'
    element.setAttribute('disabled','true')
    cardmain = cardmain.setAttribute('id','dodato')
    mainel = mainel.setAttribute('id','dodato')

}