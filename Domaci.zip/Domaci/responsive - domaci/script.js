/*const mobileMenu = () => {
    let menuul = document.querySelector('.header ul')
    let btn = document.querySelector('.header button')

    if(btn.innerText === 'MENU')
    {   
        menuul.style.display = 'block'  
        btn.innerText = 'CLOSE'
    }
    else{
        menuul.style.display = 'none'
        btn.innerText = 'MENU'
    }
} */

//event za menu button gore
let menu = document.querySelector('.header button')
menu.addEventListener("click",()=> {
    let menuul = document.querySelector('.header ul')
    let btn = document.querySelector('.header button')

    if(btn.innerText === 'MENU')
    {   
        menuul.style.display = 'block'  
        btn.innerText = 'CLOSE'
    }
    else{
        menuul.style.display = 'none'
        btn.innerText = 'MENU'
    }
})

let rightBtn = document.querySelector('#right-btn')
let leftBtn = document.querySelector('#left-btn')
let pictures = document.querySelectorAll('.slider-images img')
let imgNum = 0

const moveright =() => {
    displayNone();
    imgNum++
    if(imgNum === pictures.length){
        imgNum = 0
    }
    pictures[imgNum].style.display= 'block'
}
const moveleft = () => {
    displayNone();
    imgNum--
    if(imgNum === -1){
        imgNum = pictures.length - 1
    }
    pictures[imgNum].style.display= 'block'
}

rightBtn.addEventListener('click', moveright)
leftBtn.addEventListener('click', moveleft )

const displayNone = () => {
    pictures.forEach((img) => {
        img.style.display = 'none'
    })
}
/*
const portfolioSort = (button) => {
    let category = button.getAttribute('data-category')
    let portfolioItems = document.querySelectorAll('.portfolio-single-item')

    portfolioItems.forEach((item)=>{
        item.style.display = 'none'
    })
     
    if(category === 'sve'){
        portfolioItems.forEach((item)=>{
            item.style.display = 'block' 
        })
    }

    portfolioItems.forEach((item) =>{
        if(item.getAttribute('data-category').includes(category)){
            item.style.display = 'block'
        }
    })
}
*/
// event za portfolio {
let portfolios = document.querySelectorAll('.portfolio-categories button')
portfolios.forEach((button)=>{
    button.addEventListener("click",() =>{
        let category = button.getAttribute('data-category')
        let portfolioItems = document.querySelectorAll('.portfolio-single-item')
    
        portfolioItems.forEach((item)=>{
            item.style.display = 'none'
        })
         
        if(category === 'sve'){
            portfolioItems.forEach((item)=>{
                item.style.display = 'block' 
            })
        }
    
        portfolioItems.forEach((item) =>{
            if(item.getAttribute('data-category').includes(category)){
                item.style.display = 'block'
            }
        }) 
    })
})
// }


/*
const openModal = () =>{
    let modalWindow = document.querySelector('.popup-modal')
    let overlay = document.querySelector('.overlay')

    overlay .style.display = 'block'
    modalWindow.style.display = 'block'
}
const closeModal = () => {
    let modalWindow = document.querySelector('.popup-modal')
    let overlay = document.querySelector('.overlay')

    overlay .style.display = 'none'
    modalWindow.style.display = 'none'
}
*/
let open = document.querySelector('.modal-section button')
open.addEventListener("click", ()=>{
    let modalWindow = document.querySelector('.popup-modal')
    let overlay = document.querySelector('.overlay')

    overlay .style.display = 'block'
    modalWindow.style.display = 'block'
})

let close = document.querySelector('.popup-modal button')
close.addEventListener("click", ()=>{
    let modalWindow = document.querySelector('.popup-modal')
    let overlay = document.querySelector('.overlay')

    overlay .style.display = 'none'
    modalWindow.style.display = 'none'
})
let open2 = document.querySelector('#drugi button')
open2.addEventListener("click", ()=>{
    let modalWindow = document.querySelector('#popup-modal')
    let overlay = document.querySelector('.overlay')

    overlay .style.display = 'block'
    modalWindow.style.display = 'block'
})
let close2 = document.querySelector('#popup-modal button')
close2.addEventListener("click", ()=>{
    let modalWindow = document.querySelector('#popup-modal')
    let overlay = document.querySelector('.overlay')

    overlay .style.display = 'none'
    modalWindow.style.display = 'none'
})