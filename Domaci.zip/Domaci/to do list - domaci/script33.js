function send(){
    let input = document.querySelector('#a').value
    
    let novi = document.createElement('li')
    let btn = document.createElement('button')
    novi.className= 'novi-el'
    btn.className= 'delete'
    novi.innerText = input
    btn.innerText = 'Delete'
    btn.onclick = function(){
        novi.remove()
        btn.remove()
    }

    let body = document.querySelector('#ull')
    body.appendChild(novi) 
    body.appendChild(btn) 
    document.getElementById('a').value = "";
   
}

